package com.example.msibtest

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    private lateinit var editTextName: EditText
    private lateinit var editTextSentence: EditText
    private lateinit var btnCheck: Button
    private lateinit var btnNext: Button
    private lateinit var suitmediaPalindrome: Boolean
    private lateinit var imageView2: ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextName = findViewById(R.id.editTextName)
        editTextSentence = findViewById(R.id.editTextSentence)
        btnCheck = findViewById(R.id.btnCheck)
        btnNext = findViewById(R.id.btnNext)
        imageView2 = findViewById(R.id.imageView2)


        btnCheck.setOnClickListener {
            checkPalindrome()
        }

        btnNext.setOnClickListener {
            suitmediaPalindrome = false // Set the default value to false for the next sentence
            // Implement the logic for the "Next" button here
            // For example, you can change the sentence or perform any other action
            editTextSentence.text.clear()  // Clear the sentence input field
            showToast("Suitmedia Palindrome set to false for the next sentence.")
        }
    }

    private fun checkPalindrome() {
        val inputSentence = editTextSentence.text.toString().toLowerCase().replace("\\s".toRegex(), "")

        // Rest of your code...
    }

    // Check if the input sentence is a palindrome
    suitmediaPalindrome = inputSentence == inputSentence.reversed()

    // Display the result based on suitmediaPalindrome
    if (suitmediaPalindrome) {
        showToast("It's a Palindrome! Suitmedia Palindrome: true")
    } else {
        showToast("Not a Palindrome. Suitmedia Palindrome: false")
    }
}

private fun showToast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
}

