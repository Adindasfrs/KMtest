package com.example.msibtest
// Import statements
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Main2Activityy {


    class Main2Activity : AppCompatActivity() {

        private lateinit var textViewWelcome: TextView
        private lateinit var textViewShowName: TextView
        private lateinit var textViewSelectedUser: TextView
        private lateinit var btnChooseUser: Button

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity2_main)

            // Initialize views
            textViewWelcome= findViewById(R.id.text1)
            textViewShowName = findViewById(R.id.text2)
            textViewSelectedUser = findViewById(R.id.textView3)
            btnChooseUser = findViewById(R.id.button2)

            // Get data from the intent (assuming you passed data from the first screen)
            val showName = intent.getStringExtra("showName")
            val selectedUser = intent.getStringExtra("selectedUser")

            // Set the text for the dynamic labels
            textViewShowName.text = "Show Name: $showName"
            textViewSelectedUser.text = "Selected User: $selectedUser"

            // Set click listener for the "Choose a User" button
            btnChooseUser.setOnClickListener {
                // Navigate to the Third Screen
                val intent = Intent(this, thirdactivity::class.java)
                startActivity(intent)
            }
        }
    }

}