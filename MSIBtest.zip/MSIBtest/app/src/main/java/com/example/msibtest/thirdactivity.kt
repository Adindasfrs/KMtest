package com.example.msibtest
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity



class thirdactivity {
    class YourActivityName : AppCompatActivity() {

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.thirdactivity) // Ganti dengan nama layout file Anda

            // Kode lainnya untuk inisialisasi, manipulasi tampilan, dsb.
        }
    }
}
